$j(document).ready(function() {	

	// Init All Carousel				
	productCarousel($j('#carouselHeader'),4,4,3,2,1);				
	productCarousel($j('#megaMenuCarousel1'),1,1,1,1,1); 		
	mobileOnlyCarousel();				
	
 })